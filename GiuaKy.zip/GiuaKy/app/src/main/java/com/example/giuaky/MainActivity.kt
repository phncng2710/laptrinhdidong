package com.example.giuaky

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager


class MainActivity : AppCompatActivity() {

    // 🔹 Khởi tạo Firestore
    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("Products")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Liên kết với layout
        val name = findViewById<EditText>(R.id.editName)
        val price = findViewById<EditText>(R.id.editPrice)
        val imageUrl = findViewById<EditText>(R.id.editImage)
        val imgView = findViewById<ImageView>(R.id.imageView)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnShow = findViewById<Button>(R.id.btnShow)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        // Thêm dữ liệu
        btnAdd.setOnClickListener {
            val nameText = name.text.toString().trim()
            val priceText = price.text.toString().trim()
            val imageText = imageUrl.text.toString().trim()

            // Kiểm tra nhập đủ thông tin
            if (nameText.isEmpty() || priceText.isEmpty() || imageText.isEmpty()) {
                Toast.makeText(this, "⚠️ Vui lòng nhập đủ thông tin!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Kiểm tra giá có hợp lệ không
            val priceValue = try {
                priceText.toInt()
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "⚠️ Giá phải là số!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Kiểm tra trùng tên
            collection.whereEqualTo("name", nameText).get()
                .addOnSuccessListener { nameDocs ->
                    if (!nameDocs.isEmpty) {
                        // Nếu có sản phẩm trùng tên
                        Toast.makeText(this, "⚠️ Sản phẩm đã có tên '$nameText'!", Toast.LENGTH_SHORT).show()
                        return@addOnSuccessListener
                    }

                    // Nếu tên chưa trùng, kiểm tra trùng ảnh
                    collection.whereEqualTo("imageUrl", imageText).get()
                        .addOnSuccessListener { imageDocs ->
                            if (!imageDocs.isEmpty) {
                                // Nếu có sản phẩm trùng ảnh
                                Toast.makeText(this, "⚠️ Ảnh này đã được dùng cho sản phẩm khác!", Toast.LENGTH_SHORT).show()
                                return@addOnSuccessListener
                            }

                            // Nếu không trùng tên và ảnh → thêm mới
                            val product = hashMapOf(
                                "name" to nameText,
                                "price" to priceValue,
                                "imageUrl" to imageText
                            )

                            collection.add(product)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "✅ Đã thêm sản phẩm mới!", Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "❌ Lỗi khi thêm sản phẩm!", Toast.LENGTH_SHORT).show()
                                }
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "❌ Lỗi khi kiểm tra ảnh!", Toast.LENGTH_SHORT).show()
                        }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "❌ Lỗi khi kiểm tra tên!", Toast.LENGTH_SHORT).show()
                }
        }


        //Hiển thị sản phẩm theo tên hoặc link ảnh
        btnShow.setOnClickListener {
            collection.get()
                .addOnSuccessListener { docs ->
                    val productList = ArrayList<Product>()

                    for (doc in docs) {
                        val p = Product(
                            name = doc.getString("name") ?: "",
                            price = doc.getLong("price")?.toInt() ?: 0,
                            imageUrl = doc.getString("imageUrl") ?: ""
                        )
                        productList.add(p)
                    }

                    val rv = findViewById<RecyclerView>(R.id.recyclerProducts)
                    rv.adapter = ProductAdapter(productList)
                    rv.layoutManager = LinearLayoutManager(this)

                    Toast.makeText(this, "✅ Đã tải ${productList.size} sản phẩm!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "❌ Lỗi tải danh sách!", Toast.LENGTH_SHORT).show()
                }
        }


        btnUpdate.setOnClickListener {
            collection.whereEqualTo("name", name.text.toString())
                .get()
                .addOnSuccessListener { docs ->
                    for (doc in docs) {
                        collection.document(doc.id).update(
                            "price", price.text.toString().toInt(),
                            "imageUrl", imageUrl.text.toString()
                        )
                        Toast.makeText(this, "Đã cập nhật!", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        btnDelete.setOnClickListener {
            collection.whereEqualTo("name", name.text.toString())
                .get()
                .addOnSuccessListener { docs ->
                    for (doc in docs) {
                        collection.document(doc.id).delete()
                        Toast.makeText(this, "Đã xóa!", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}
